﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Linq;
using Newtonsoft.Json;

namespace ELANZI_SOFIANE_ST2API_TP2
{
    class Program
    {
        HttpClient client = new HttpClient();
        static async Task Main(string[] args)
        {
            Program program = new Program();
            await program.Oslo();
            await program.Jakarta();
            await program.Windy();
            await program.Pressure();
        }

        private async Task Oslo()
        {
            string response = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=59.9138688&lon=10.7522454&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");

            string stringjson = JsonConvert.SerializeObject(response);
            File.WriteAllText(@"WTH.json", stringjson);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(response);
            Console.Write("The sunrinse in Oslo : " + myDeserializedClass.current.sunrise);
            Console.Write("The sunsest in Oslo : " + myDeserializedClass.current.sunset);
        }

        private async Task Jakarta()
        {
            string response = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=-6.200000&lon=106.816666&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");

            string stringjson = JsonConvert.SerializeObject(response);
            File.WriteAllText(@"Jakarata.json", stringjson);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(response);
            Console.WriteLine("/n");
            Console.WriteLine("The temperature in Jakarta : " + myDeserializedClass.current.temp + " degre celcius");
        }

        private async Task Windy()
        {
            string NY = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=40.712784&lon=-74.005941&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");
            string Tokyo = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=35.6894&lon=139.692&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");
            string Paris = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=48.856614&lon=2.3522219&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");

            string stringjsonNY = JsonConvert.SerializeObject(NY);
            File.WriteAllText(@"NY.json", stringjsonNY);
            string stringjsonTK = JsonConvert.SerializeObject(Tokyo);
            File.WriteAllText(@"TK.json", stringjsonTK);
            string stringjsonPr = JsonConvert.SerializeObject(Paris);
            File.WriteAllText(@"Pr.json", stringjsonPr);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(NY);
            Root myDeserializedClass2 = JsonConvert.DeserializeObject<Root>(Tokyo);
            Root myDeserializedClass3 = JsonConvert.DeserializeObject<Root>(Paris);
            if (myDeserializedClass.current.wind_speed > myDeserializedClass2.current.wind_speed && myDeserializedClass.current.wind_speed > myDeserializedClass3.current.wind_speed)
            {
                Console.WriteLine("/n");

                Console.WriteLine("The wind is stronger in NY (" + myDeserializedClass.current.wind_speed + ") than in Tokyo and Paris");
            }
            else if (myDeserializedClass.current.wind_speed < myDeserializedClass2.current.wind_speed && myDeserializedClass.current.wind_speed < myDeserializedClass3.current.wind_speed)
            {
                Console.WriteLine("/n");

                Console.WriteLine("The wind is stronger in Paris (" + myDeserializedClass3.current.wind_speed + ") than in Tokyo and NY");
            }
            else
            {
                Console.WriteLine("/n");

                Console.WriteLine("The wind is stronger in Tokyo (" + myDeserializedClass2.current.wind_speed + ") than in Paris and NY");
            }




        }

        private async Task Pressure()
        {
            string Kiev = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=50.4501&lon=30.5234&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");
            string Moscow = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=55.755826&lon=37.6173&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");
            string Berlin = await client.GetStringAsync("https://api.openweathermap.org/data/2.5/onecall?lat=52.520007&lon=13.404954&lang=fr&units=metric&exclude=hourly,daily,minutely,alerts,pressure&appid=f4df0a1cbb9d94c62b6727639c7d9dc8");
            string stringjsonKiev = JsonConvert.SerializeObject(Kiev);
            File.WriteAllText(@"Kiev.json", stringjsonKiev);
            string stringjsonMoscow = JsonConvert.SerializeObject(Moscow);
            File.WriteAllText(@"Moscow.json", stringjsonMoscow);
            string stringjsonBerlin = JsonConvert.SerializeObject(Berlin);
            File.WriteAllText(@"Berlin.json", stringjsonBerlin);
            Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(Kiev);
            Root myDeserializedClass2 = JsonConvert.DeserializeObject<Root>(Moscow);
            Root myDeserializedClass3 = JsonConvert.DeserializeObject<Root>(Berlin);
            Console.WriteLine("");
            Console.WriteLine("By Kiev, the humidity is about " + myDeserializedClass.current.humidity + "% and the pressure : " + myDeserializedClass.current.pressure + " hPa");
            Console.WriteLine("By Moscow, the humidity is about " + myDeserializedClass2.current.humidity + "% and the pressure : " + myDeserializedClass2.current.pressure + " hPa");
            Console.WriteLine("By Berlin, the humidity is about " + myDeserializedClass3.current.humidity + "% and the pressure: " + myDeserializedClass3.current.pressure + " hPa");



        }


    }

    public class Weather
    {
        public int id { get; set; }
        public string main { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
    }

    public class Current
    {
        public int dt { get; set; }
        public int sunrise { get; set; }
        public int sunset { get; set; }
        public double temp { get; set; }
        public double feels_like { get; set; }
        public int pressure { get; set; }
        public int humidity { get; set; }
        public double dew_point { get; set; }
        public double uvi { get; set; }
        public int clouds { get; set; }
        public int visibility { get; set; }
        public double wind_speed { get; set; }
        public int wind_deg { get; set; }
        public double wind_gust { get; set; }
        public List<Weather> weather { get; set; }
    }

    public class Root
    {
        public double lat { get; set; }
        public double lon { get; set; }
        public string timezone { get; set; }
        public int timezone_offset { get; set; }
        public Current current { get; set; }
    }






}


